"""Integration tests for the CERBERUS-X pipeline."""

import json
from pathlib import Path

from core.reasoner import answer_question
from core.schemas import AnswerStatus, ConflictType
from pipeline import run_pipeline
from tests.test_extractor import _write_minimal_xlsx


def test_pipeline_processes_demo_files():

    root = Path(__file__).resolve().parents[1]
    demo_dir = root / "demo_data"

    files = [
        demo_dir / "case1_quantity_conflict.csv",
        demo_dir / "case2_order_vs_dispatch.txt",
        demo_dir / "case3_leadership.txt",
        demo_dir / "case4_hidden_instruction.pdf",
        demo_dir / "case5_timeline.txt"
    ]

    if not all(path.exists() for path in files):
        return

    result = run_pipeline(files)

    assert len(result.documents) == 5
    assert len(result.claims) > 0


def test_pipeline_does_not_read_ground_truth():

    root = Path(__file__).resolve().parents[1]

    demo_dir = root / "demo_data"

    assert not (demo_dir / "expected.json").exists()


def test_pipeline_cross_modality_excel_and_json_conflict(tmp_path):
    xlsx = tmp_path / "warehouse.xlsx"
    _write_minimal_xlsx(
        xlsx,
        {
            "Dispatches": [
                ["source", "entity", "attribute", "value", "unit", "timestamp"],
                ["Warehouse Ledger", "Shipment SH-500", "quantity_dispatched", "120", "units", "2026-05-01 09:00"],
            ]
        },
    )
    js = tmp_path / "courier.json"
    js.write_text(
        json.dumps(
            {
                "records": [
                    {
                        "source": "Courier API",
                        "entity": "Shipment SH-500",
                        "attribute": "quantity_dispatched",
                        "value": 95,
                        "unit": "units",
                        "timestamp": "2026-05-01 09:30",
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    result = run_pipeline([xlsx, js])
    assert any(c.conflict_type == ConflictType.TRUE_CONFLICT for c in result.conflicts)
    ans = answer_question("How many units of Shipment SH-500 were dispatched?", result)
    assert ans.status == AnswerStatus.CONFLICTING
    assert "120" in ans.answer_text and "95" in ans.answer_text