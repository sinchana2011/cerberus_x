from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from core.extractor import extract_file
from core.sanitizer import sanitize
from core.entity_resolver import EntityResolver

from core.schemas import (
    AnalysisResult,
    Claim,
    ClaimStatus,
    WorkflowStage,
    make_id,
)

from core.graph_engine import (
    EvidenceGraph,
    detect_conflicts,
)

from core.digital_twin import build_twin_states


DATE_FORMATS = [
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d",
    "%Y/%m/%d",
]


def parse_date(text):

    for fmt in DATE_FORMATS:

        try:
            return datetime.strptime(text, fmt)

        except ValueError:
            continue

    return None


def _infer_entity_type(entity_name: str, predicate: str) -> str:
    if re.search(r"\b(shipment|truck|vehicle)\b", entity_name, re.I):
        return "shipment"
    if re.search(r"\b(purchase order|po-)\b", entity_name, re.I):
        return "order"
    if predicate.startswith("role:"):
        return "organization"
    if predicate == "location":
        return "person"
    return "unknown"


def _add_claim(
    claims,
    resolver,
    document,
    segment,
    entity_name,
    predicate,
    value,
    stage=WorkflowStage.UNKNOWN,
    event_time=None,
    location=None,
    unit=None,
    source_label=None,
    entity_type=None,
):

    if not entity_name or not value:
        return

    resolved_type = entity_type or _infer_entity_type(entity_name, predicate)

    match = resolver.resolve(
        entity_name,
        resolved_type,
    )

    claim = Claim(
        id=make_id(
            "clm",
            document.id,
            segment.locator,
            predicate,
            value,
        ),
        source_id=document.id,
        source_label=source_label,
        entity_name=entity_name,
        entity_id=match.entity_id,
        predicate=predicate,
        value=str(value),
        value_num=(
            float(value)
            if str(value).replace(".", "", 1).isdigit()
            else None
        ),
        unit=unit,
        stage=stage,
        event_time=event_time,
        location=location,
        raw_text=segment.text,
        locator=segment.locator,
        suspicious=False,
        status=ClaimStatus.UNVERIFIED,
    )

    claims.append(claim)


def _extract_structured_claim(claims, resolver, document, segment, fields):
    entity = fields.get("entity", "")
    attribute = fields.get("attribute", "")
    value = fields.get("value", "")
    if not (entity and attribute and value):
        return

    unit = fields.get("unit") or None
    timestamp = fields.get("timestamp")
    source_label = fields.get("source") or None
    attr_lower = attribute.lower()

    stage = WorkflowStage.UNKNOWN
    if "dispatch" in attr_lower:
        stage = WorkflowStage.DISPATCHED
    elif "order" in attr_lower:
        stage = WorkflowStage.ORDERED
    elif "deliver" in attr_lower:
        stage = WorkflowStage.DELIVERED
    elif "invoic" in attr_lower:
        stage = WorkflowStage.INVOICED

    predicate = "quantity" if "quantity" in attr_lower or stage != WorkflowStage.UNKNOWN else attribute
    event_time = parse_date(timestamp) if timestamp else None
    location = fields.get("location") or None

    _add_claim(
        claims,
        resolver,
        document,
        segment,
        entity,
        predicate,
        value,
        stage=stage,
        event_time=event_time,
        location=location,
        unit=unit,
        source_label=source_label,
    )


_QUANTITY_ENTITY_RE = re.compile(
    r"(?P<entity>(?:Shipment|Purchase Order|PO)[\s-]*[A-Z0-9-]+)",
    re.I,
)
_QUANTITY_ACTIVE_RE = re.compile(
    r"\b(?P<verb>ordered|dispatched|delivered|invoiced)"
    r"\s+(?P<number>\d+(?:\.\d+)?)"
    r"\s+(?P<unit>units?|items?|pieces?)\b",
    re.I,
)
_QUANTITY_PASSIVE_RE = re.compile(
    r"\b(?P<number>\d+(?:\.\d+)?)\s+(?P<unit>units?|items?|pieces?)"
    r"\s+of\s+(?P<entity>(?:Shipment|Purchase Order|PO)[\s-]*[A-Z0-9-]+)"
    r".*?\b(?P<verb>ordered|dispatched|delivered|invoiced)\b",
    re.I,
)
_ROLE_RE = re.compile(
    r"(?P<person>[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)"
    r"\s+(?:is|was)\s+the\s+"
    r"(?P<role>CEO|CFO|CTO|manager)"
    r"\s+of\s+"
    r"(?P<org>[A-Z][A-Za-z0-9& ]+?)(?=[,.]|$)",
)
_SUCCEEDS_RE = re.compile(
    r"(?P<successor>[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)"
    r"\s+succeeds\s+"
    r"(?P<predecessor>(?:[A-Z]\.\s*|[A-Z][a-z]+\s+)[A-Z][a-z]+)"
)
_MOVEMENT_RE = re.compile(
    r"(?P<entity>Truck\s+[A-Z0-9-]+)"
    r"\s+(?P<action>departed|arrived)"
    r"(?:\s+(?:in|at|from|to))?"
    r"\s+(?P<place>[A-Z][A-Za-z ]+?)"
    r"\s+on\s+"
    r"(?P<date>\d{4}-\d{2}-\d{2})"
    r"\s+at\s+"
    r"(?P<time>\d{2}:\d{2})",
    re.I,
)
_PERSON_LOC_RE = re.compile(
    r"(?:(?:Inspector|Auditor|Dr\.|Mr\.|Ms\.|Mrs\.)\s+)?"
    r"(?P<person>[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)"
    r"\s+(?:signed|attended|visited|was|is)"
    r".*?(?:\bin\s+|\bvisited\s+(?:the\s+)?|\b(?:the\s+)?)"
    r"(?P<place>Mumbai|Pune|Delhi|Bengaluru|Chennai)"
    r".*?"
    r"(?P<date>\d{4}-\d{2}-\d{2})"
    r"(?:\s+at\s+(?P<time>\d{2}:\d{2}))?",
)
_HEADER_DATE_RE = re.compile(r"^\s*Date\s*:\s*(\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2})?)\s*$", re.I)
_INLINE_DATE_RE = re.compile(r"\b(\d{4}-\d{2}-\d{2})\b")
_STAGE_BY_VERB = {
    "ordered": WorkflowStage.ORDERED,
    "dispatched": WorkflowStage.DISPATCHED,
    "delivered": WorkflowStage.DELIVERED,
    "invoiced": WorkflowStage.INVOICED,
}


def extract_claims(
    document,
    sanitized,
    resolver,
):

    claims = []
    context_date = None

    for item in sanitized.segments:

        segment = item.segment

        # Never extract factual claims from withheld evidence.
        if item.suspicious:
            continue

        text = segment.text.strip()

        if not text:
            continue

        # --------------------------------------------------
        # 1. Structured tabular / JSON records
        # --------------------------------------------------

        fields = segment.fields or {}

        if fields:
            _extract_structured_claim(claims, resolver, document, segment, fields)
            continue

        # Track section/document-level Date headers for following lines.
        header_date = _HEADER_DATE_RE.match(text)
        if header_date:
            context_date = parse_date(header_date.group(1))
            continue

        inline_date_match = _INLINE_DATE_RE.search(text)
        line_date = parse_date(inline_date_match.group(1)) if inline_date_match else context_date

        # --------------------------------------------------
        # 2. Quantity claims (active & passive phrasing)
        # --------------------------------------------------

        passive = _QUANTITY_PASSIVE_RE.search(text)
        if passive:
            verb = passive.group("verb").lower()
            _add_claim(
                claims,
                resolver,
                document,
                segment,
                passive.group("entity"),
                "quantity",
                passive.group("number"),
                _STAGE_BY_VERB[verb],
                event_time=line_date,
                unit=passive.group("unit"),
            )
        else:
            quantity_match = _QUANTITY_ENTITY_RE.search(text)
            quantity = _QUANTITY_ACTIVE_RE.search(text)
            if quantity_match and quantity:
                verb = quantity.group("verb").lower()
                _add_claim(
                    claims,
                    resolver,
                    document,
                    segment,
                    quantity_match.group("entity"),
                    "quantity",
                    quantity.group("number"),
                    _STAGE_BY_VERB[verb],
                    event_time=line_date,
                    unit=quantity.group("unit"),
                )

        # --------------------------------------------------
        # 3. CEO / role claims & succession aliases
        # --------------------------------------------------

        role_match = _ROLE_RE.search(text)
        if role_match:
            person = role_match.group("person").strip()
            role = role_match.group("role").strip()
            org = role_match.group("org").strip().rstrip(".")

            resolver.resolve(person, "person")
            _add_claim(
                claims,
                resolver,
                document,
                segment,
                org,
                "role:" + role.upper(),
                person,
                event_time=line_date,
                entity_type="organization",
            )

        succeeds_match = _SUCCEEDS_RE.search(text)
        if succeeds_match:
            resolver.resolve(succeeds_match.group("successor").strip(), "person")
            resolver.resolve(succeeds_match.group("predecessor").strip(), "person")

        # --------------------------------------------------
        # 4. Transport departure and arrival
        # --------------------------------------------------

        movement = _MOVEMENT_RE.search(text)
        if movement:
            entity = movement.group("entity")
            action = movement.group("action").lower()
            place = movement.group("place").strip()

            event_time = parse_date(
                movement.group("date") + " " + movement.group("time")
            )

            _add_claim(
                claims,
                resolver,
                document,
                segment,
                entity,
                action,
                place,
                event_time=event_time,
                location=place,
            )

        # --------------------------------------------------
        # 5. Person location claims
        # --------------------------------------------------

        person_location = _PERSON_LOC_RE.search(text)
        if person_location:
            person = person_location.group("person").strip()
            place = person_location.group("place").strip()

            date_text = person_location.group("date")
            time_text = person_location.group("time") or "00:00"

            event_time = parse_date(date_text + " " + time_text)

            _add_claim(
                claims,
                resolver,
                document,
                segment,
                person,
                "location",
                place,
                event_time=event_time,
                location=place,
                entity_type="person",
            )

    return claims


class CerberusPipeline:

    def __init__(self):

        self.resolver = EntityResolver()
        self.evidence_graph = EvidenceGraph()

    def process_files(
        self,
        paths,
        save_path=None,
    ):

        result = AnalysisResult()

        for path in paths:

            path = Path(path)

            extraction = extract_file(path)

            if not extraction.ok:

                result.warnings.append(
                    f"{path.name}: {extraction.error}"
                )

                continue

            sanitized = sanitize(extraction)

            document = sanitized.document

            result.documents.append(document)

            result.warnings.extend(
                sanitized.warnings
            )

            claims = extract_claims(
                document,
                sanitized,
                self.resolver,
            )

            result.claims.extend(claims)

        result.entities = self.resolver.entities

        # Identify conflicts and duplicates.
        result.conflicts = detect_conflicts(
            result.claims
        )

        # Construct digital twin states.
        result.twin_states = build_twin_states(
            result
        )

        # Construct evidence graph after conflict assessment and twin state construction.
        self.evidence_graph.build(result)

        if save_path:

            result.save_json(
                Path(save_path)
            )

        return result


def run_pipeline(paths, save_path=None):

    pipeline = CerberusPipeline()

    return pipeline.process_files(
        paths,
        save_path=save_path,
    )


if __name__ == "__main__":

    demo_folder = Path("demo_data")

    files = [
        demo_folder / "case1_quantity_conflict.csv",
        demo_folder / "case2_order_vs_dispatch.txt",
        demo_folder / "case3_leadership.txt",
        demo_folder / "case4_hidden_instruction.pdf",
        demo_folder / "case5_timeline.txt",
    ]

    result = run_pipeline(
        files,
        save_path="data/analysis/analysis.json",
    )

    print("\nCERBERUS-X ANALYSIS COMPLETE")
    print("-" * 40)

    print("Documents:", len(result.documents))
    print("Entities:", len(result.entities))
    print("Claims:", len(result.claims))
    print("Conflicts:", len(result.conflicts))
    print("Digital Twin States:", len(result.twin_states))

    print("\nDetected Conflicts:")

    for conflict in result.conflicts:

        print(
            conflict.conflict_type.value,
            "->",
            conflict.explanation,
        )