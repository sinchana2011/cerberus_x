import * as React from "react";

import { extractApiError, fetchAnalysis, fetchHealth } from "@/lib/api";
import type { AnalysisDetailResponse, HealthResponse } from "@/types/cerberus";

const STORAGE_ACTIVE_KEY = "cerberus_active_analysis_id";
const STORAGE_HISTORY_KEY = "cerberus_investigation_history";

export interface SavedInvestigationEntry {
  analysis_id: string;
  created_at: string;
  documents: number;
  entities: number;
  claims: number;
  conflicts: number;
}

interface AnalysisContextValue {
  health: HealthResponse | null;
  healthLoading: boolean;
  healthError: string | null;
  refreshHealth: () => Promise<void>;
  activeAnalysisId: string | null;
  activeAnalysis: AnalysisDetailResponse | null;
  analysisLoading: boolean;
  analysisError: string | null;
  history: SavedInvestigationEntry[];
  selectAnalysis: (analysisId: string) => Promise<boolean>;
  clearActiveAnalysis: () => void;
}

const AnalysisContext = React.createContext<AnalysisContextValue | undefined>(undefined);

function readStoredHistory(): SavedInvestigationEntry[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function AnalysisProvider({ children }: { children: React.ReactNode }) {
  const [health, setHealth] = React.useState<HealthResponse | null>(null);
  const [healthLoading, setHealthLoading] = React.useState<boolean>(true);
  const [healthError, setHealthError] = React.useState<string | null>(null);

  const [activeAnalysisId, setActiveAnalysisId] = React.useState<string | null>(() => {
    try {
      return window.localStorage.getItem(STORAGE_ACTIVE_KEY);
    } catch {
      return null;
    }
  });
  const [activeAnalysis, setActiveAnalysis] = React.useState<AnalysisDetailResponse | null>(null);
  const [analysisLoading, setAnalysisLoading] = React.useState<boolean>(false);
  const [analysisError, setAnalysisError] = React.useState<string | null>(null);
  const [history, setHistory] = React.useState<SavedInvestigationEntry[]>(readStoredHistory);

  const refreshHealth = React.useCallback(async () => {
    setHealthLoading(true);
    setHealthError(null);
    try {
      const data = await fetchHealth();
      setHealth(data);
    } catch (err) {
      setHealth(null);
      setHealthError(extractApiError(err));
    } finally {
      setHealthLoading(false);
    }
  }, []);

  const recordHistory = React.useCallback((detail: AnalysisDetailResponse) => {
    const entry: SavedInvestigationEntry = {
      analysis_id: detail.analysis_id,
      created_at: detail.created_at,
      documents: detail.counts.documents,
      entities: detail.counts.entities,
      claims: detail.counts.claims,
      conflicts: detail.counts.conflicts,
    };
    setHistory((prev) => {
      const next = [entry, ...prev.filter((item) => item.analysis_id !== entry.analysis_id)].slice(
        0,
        20
      );
      try {
        window.localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota errors in restricted environments.
      }
      return next;
    });
  }, []);

  const selectAnalysis = React.useCallback(
    async (analysisId: string): Promise<boolean> => {
      const trimmed = analysisId.trim();
      if (!trimmed) return false;
      setAnalysisLoading(true);
      setAnalysisError(null);
      try {
        const detail = await fetchAnalysis(trimmed);
        setActiveAnalysisId(trimmed);
        setActiveAnalysis(detail);
        try {
          window.localStorage.setItem(STORAGE_ACTIVE_KEY, trimmed);
        } catch {
          // Ignore storage failures.
        }
        recordHistory(detail);
        return true;
      } catch (err) {
        setAnalysisError(extractApiError(err));
        return false;
      } finally {
        setAnalysisLoading(false);
      }
    },
    [recordHistory]
  );

  const clearActiveAnalysis = React.useCallback(() => {
    setActiveAnalysisId(null);
    setActiveAnalysis(null);
    setAnalysisError(null);
    try {
      window.localStorage.removeItem(STORAGE_ACTIVE_KEY);
    } catch {
      // Ignore storage failures.
    }
  }, []);

  React.useEffect(() => {
    void refreshHealth();
    if (activeAnalysisId) {
      void selectAnalysis(activeAnalysisId);
    }
    // Run once on initial mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AnalysisContext.Provider
      value={{
        health,
        healthLoading,
        healthError,
        refreshHealth,
        activeAnalysisId,
        activeAnalysis,
        analysisLoading,
        analysisError,
        history,
        selectAnalysis,
        clearActiveAnalysis,
      }}
    >
      {children}
    </AnalysisContext.Provider>
  );
}

export function useAnalysis() {
  const ctx = React.useContext(AnalysisContext);
  if (!ctx) {
    throw new Error("useAnalysis must be used inside AnalysisProvider");
  }
  return ctx;
}
