"""Unit tests for the CERBERUS-X evidence graph and conflict detector."""

from datetime import datetime

from core.graph_engine import EvidenceGraph, detect_conflicts
from core.schemas import (
    AnalysisResult,
    Claim,
    ClaimStatus,
    ConflictType,
    Entity,
    FileType,
    SourceDocument,
    SourceType,
    WorkflowStage,
)


def _claim(
    cid: str,
    *,
    source_id: str = "doc_1",
    source_label: str | None = None,
    entity_id: str = "ent_1",
    entity_name: str = "Entity 1",
    predicate: str = "quantity",
    value: str = "10",
    stage: WorkflowStage = WorkflowStage.UNKNOWN,
    event_time: datetime | None = None,
    location: str | None = None,
    raw_text: str | None = None,
    suspicious: bool = False,
) -> Claim:
    return Claim(
        id=cid,
        source_id=source_id,
        source_label=source_label,
        entity_id=entity_id,
        entity_name=entity_name,
        predicate=predicate,
        value=value,
        stage=stage,
        event_time=event_time,
        location=location,
        raw_text=raw_text or f"{entity_name} {predicate} {value}",
        suspicious=suspicious,
    )


def test_detects_true_conflict_and_duplicate_for_same_stage_quantity():
    c1 = _claim(
        "c1",
        source_label="Warehouse System",
        entity_name="Shipment SH-1042",
        value="85",
        stage=WorkflowStage.DISPATCHED,
        event_time=datetime(2026, 3, 10, 14, 0),
        raw_text="record_id=R1; entity=Shipment SH-1042; value=85",
    )
    c2 = _claim(
        "c2",
        source_label="Courier Manifest",
        entity_name="Shipment SH-1042",
        value="100",
        stage=WorkflowStage.DISPATCHED,
        event_time=datetime(2026, 3, 10, 15, 30),
        raw_text="record_id=R2; entity=Shipment SH-1042; value=100",
    )
    c3 = _claim(
        "c3",
        source_label="Warehouse System",
        entity_name="Shipment SH-1042",
        value="85",
        stage=WorkflowStage.DISPATCHED,
        event_time=datetime(2026, 3, 10, 14, 0),
        raw_text="record_id=R3; entity=Shipment SH-1042; value=85",
    )

    conflicts = detect_conflicts([c1, c2, c3])
    types = {c.conflict_type for c in conflicts}

    assert ConflictType.DUPLICATE in types
    assert ConflictType.TRUE_CONFLICT in types
    assert ConflictType.WORKFLOW_STAGE not in types
    assert c3.status == ClaimStatus.DUPLICATE
    assert c1.status == ClaimStatus.DISPUTED
    assert c2.status == ClaimStatus.DISPUTED


def test_detects_workflow_stage_without_true_conflict():
    ordered = _claim(
        "c1",
        entity_name="Purchase Order PO-7781",
        value="100",
        stage=WorkflowStage.ORDERED,
        event_time=datetime(2026, 3, 1),
    )
    dispatched = _claim(
        "c2",
        entity_name="Purchase Order PO-7781",
        value="85",
        stage=WorkflowStage.DISPATCHED,
        event_time=datetime(2026, 3, 12),
    )

    conflicts = detect_conflicts([ordered, dispatched])
    assert [c.conflict_type for c in conflicts] == [ConflictType.WORKFLOW_STAGE]
    assert not conflicts[0].is_real_problem
    assert ordered.status == ClaimStatus.VERIFIED
    assert dispatched.status == ClaimStatus.VERIFIED


def test_detects_temporal_change_and_supersedes_older_claim():
    old = _claim(
        "c1",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Rahul Sharma",
        event_time=datetime(2024, 6, 1),
    )
    new = _claim(
        "c2",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Priya Nair",
        event_time=datetime(2026, 2, 15),
    )

    conflicts = detect_conflicts([old, new])
    assert [c.conflict_type for c in conflicts] == [ConflictType.TEMPORAL_CHANGE]
    assert old.status == ClaimStatus.SUPERSEDED
    assert new.status == ClaimStatus.VERIFIED


def test_detects_same_event_conflict_and_compatible_different_time():
    pune_apr2 = _claim(
        "c1",
        entity_name="Meera Das",
        predicate="location",
        value="Pune",
        location="Pune",
        event_time=datetime(2026, 4, 2, 9, 0),
    )
    delhi_apr2 = _claim(
        "c2",
        entity_name="Meera Das",
        predicate="location",
        value="Delhi",
        location="Delhi",
        event_time=datetime(2026, 4, 2, 9, 0),
    )
    delhi_apr5 = _claim(
        "c3",
        entity_name="Meera Das",
        predicate="location",
        value="Delhi",
        location="Delhi",
        event_time=datetime(2026, 4, 5, 11, 0),
    )

    conflicts = detect_conflicts([pune_apr2, delhi_apr2, delhi_apr5])
    types = {c.conflict_type for c in conflicts}
    assert ConflictType.SAME_EVENT_CONFLICT in types
    assert ConflictType.COMPATIBLE_DIFFERENT_TIME in types
    assert pune_apr2.status == ClaimStatus.DISPUTED
    assert delhi_apr2.status == ClaimStatus.DISPUTED
    assert delhi_apr5.status == ClaimStatus.VERIFIED


def test_detects_impossible_timeline():
    dep = _claim(
        "c1",
        entity_name="Truck TR-55",
        predicate="departed",
        value="Mumbai",
        location="Mumbai",
        event_time=datetime(2026, 4, 2, 10, 0),
    )
    arr = _claim(
        "c2",
        entity_name="Truck TR-55",
        predicate="arrived",
        value="Pune",
        location="Pune",
        event_time=datetime(2026, 4, 2, 8, 0),
    )

    conflicts = detect_conflicts([dep, arr])
    assert [c.conflict_type for c in conflicts] == [ConflictType.IMPOSSIBLE_TIMELINE]
    assert conflicts[0].is_real_problem
    assert dep.status == ClaimStatus.DISPUTED
    assert arr.status == ClaimStatus.DISPUTED


def test_suspicious_claims_are_excluded_from_conflict_detection():
    clean = _claim("c1", entity_name="Shipment SH-2201", value="60", stage=WorkflowStage.DELIVERED)
    evil = _claim(
        "c2",
        entity_name="Shipment SH-2201",
        value="100",
        stage=WorkflowStage.DELIVERED,
        suspicious=True,
    )

    conflicts = detect_conflicts([clean, evil])
    assert conflicts == []
    assert clean.status == ClaimStatus.VERIFIED
    assert evil.status == ClaimStatus.SUSPICIOUS


def test_evidence_graph_builds_nodes_edges_and_statistics():
    doc = SourceDocument(
        id="doc_1",
        filename="report.txt",
        file_type=FileType.TEXT,
        source_type=SourceType.FREEFORM_NOTE,
        sha256="a" * 64,
    )
    ent = Entity(id="ent_1", canonical_name="Shipment SH-1042", entity_type="shipment")
    c1 = _claim("c1", value="85", stage=WorkflowStage.DISPATCHED)
    c2 = _claim("c2", source_label="Courier", value="100", stage=WorkflowStage.DISPATCHED)
    conflicts = detect_conflicts([c1, c2])

    result = AnalysisResult(documents=[doc], entities=[ent], claims=[c1, c2], conflicts=conflicts)
    graph = EvidenceGraph()
    graph.build(result)
    stats = graph.statistics()

    assert stats == {
        "nodes": 5,
        "edges": 6,
        "documents": 1,
        "entities": 1,
        "claims": 2,
        "conflicts": 1,
    }
