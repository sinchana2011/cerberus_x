import {
  AlertTriangle,
  Cpu,
  FileSearch,
  GitBranch,
  HardDrive,
  LayoutDashboard,
  MessageSquareText,
  ShieldAlert,
  UploadCloud,
} from "lucide-react";
import { NavLink } from "react-router-dom";

import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  ready: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, ready: true },
  { to: "/upload", label: "Document Upload", icon: UploadCloud, ready: false },
  { to: "/graph", label: "Evidence Graph", icon: GitBranch, ready: false },
  { to: "/conflicts", label: "Conflict Detection", icon: AlertTriangle, ready: false },
  { to: "/digital-twin", label: "Digital Twin", icon: Cpu, ready: false },
  { to: "/ask", label: "AI Q&A", icon: MessageSquareText, ready: false },
  { to: "/forensics", label: "Forensic Inspector", icon: ShieldAlert, ready: false },
];

export function Sidebar({
  mobileOpen,
  onClose,
}: {
  mobileOpen: boolean;
  onClose: () => void;
}) {
  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-slate-950/40 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-navy-950 text-slate-200 transition-transform duration-200 lg:static lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-16 items-center gap-3 border-b border-white/10 px-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600/20 text-blue-400 ring-1 ring-blue-400/30">
            <FileSearch className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-bold tracking-wide text-white">CERBERUS-X</div>
            <div className="truncate text-[11px] text-slate-400">
              Multimodal Forensics
            </div>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label="Primary">
          <div className="px-2 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Investigation Workspace
          </div>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                onClick={onClose}
                className={({ isActive }) =>
                  cn(
                    "group flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-blue-600/20 text-white ring-1 ring-blue-500/40"
                      : "text-slate-300 hover:bg-white/5 hover:text-white"
                  )
                }
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4 shrink-0 text-blue-400" />
                  <span>{item.label}</span>
                </span>
                {!item.ready && (
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-normal text-slate-300">
                    Next
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="border-t border-white/10 p-4">
          <div className="rounded-lg bg-navy-900/90 p-3 ring-1 ring-white/10">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
              <HardDrive className="h-3.5 w-3.5" />
              <span>Localhost Isolated</span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed text-slate-400">
              All evidence, SQLite storage, and reasoning run locally with zero external
              network calls.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
