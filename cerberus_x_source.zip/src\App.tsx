import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AnalysisProvider } from "@/context/AnalysisContext";
import { NotificationProvider } from "@/context/NotificationContext";
import { DashboardPage } from "@/pages/DashboardPage";

export function App() {
  return (
    <NotificationProvider>
      <AnalysisProvider>
        <DashboardPage />
      </AnalysisProvider>
    </NotificationProvider>
  );
}

export default App;