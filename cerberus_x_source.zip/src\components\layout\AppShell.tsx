import * as React from "react";
import { AlertCircle, CheckCircle2, Info, X, AlertTriangle } from "lucide-react";

import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { useNotifications, type NotificationKind } from "@/context/NotificationContext";
import { cn } from "@/lib/utils";

const KIND_STYLES: Record<NotificationKind, string> = {
  info: "border-blue-200 bg-white text-slate-900",
  success: "border-emerald-200 bg-white text-slate-900",
  warning: "border-amber-200 bg-white text-slate-900",
  error: "border-red-200 bg-white text-slate-900",
};

function NotificationIcon({ kind }: { kind: NotificationKind }) {
  if (kind === "success") return <CheckCircle2 className="h-4 w-4 text-emerald-600" />;
  if (kind === "warning") return <AlertTriangle className="h-4 w-4 text-amber-600" />;
  if (kind === "error") return <AlertCircle className="h-4 w-4 text-red-600" />;
  return <Info className="h-4 w-4 text-blue-600" />;
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const { notifications, dismiss } = useNotifications();

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar onOpenMobileNav={() => setMobileOpen(true)} />

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:px-8">
          {children}
        </main>
      </div>

      {notifications.length > 0 && (
        <div
          className="fixed bottom-4 right-4 z-50 flex w-full max-w-sm flex-col gap-2 px-4 sm:px-0"
          aria-live="polite"
        >
          {notifications.map((item) => (
            <div
              key={item.id}
              className={cn(
                "flex items-start gap-3 rounded-lg border p-3.5 shadow-lg transition-all",
                KIND_STYLES[item.kind]
              )}
            >
              <div className="mt-0.5 shrink-0">
                <NotificationIcon kind={item.kind} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold">{item.title}</div>
                {item.message && (
                  <div className="mt-0.5 text-xs text-slate-600">{item.message}</div>
                )}
              </div>
              <button
                type="button"
                onClick={() => dismiss(item.id)}
                className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Dismiss notification"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
