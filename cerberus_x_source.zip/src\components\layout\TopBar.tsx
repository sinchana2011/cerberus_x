import { Activity, Menu, RefreshCw, ShieldCheck, WifiOff } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAnalysis } from "@/context/AnalysisContext";

export function TopBar({ onOpenMobileNav }: { onOpenMobileNav: () => void }) {
  const { health, healthLoading, refreshHealth, activeAnalysisId } = useAnalysis();
  const isOnline = health?.status === "ok";

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-sm sm:px-6">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={onOpenMobileNav}
          aria-label="Open navigation"
        >
          <Menu className="h-5 w-5" />
        </Button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-semibold text-slate-900 sm:text-base">
              Evidence Intelligence Platform
            </h1>
            {activeAnalysisId && (
              <Badge variant="info" className="hidden font-mono sm:inline-flex">
                {activeAnalysisId}
              </Badge>
            )}
          </div>
          <p className="hidden text-xs text-slate-500 sm:block">
            Cross-modal contradiction detection & traceable investigation
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <Badge variant="neutral" className="hidden gap-1.5 border-slate-300 bg-slate-100 md:inline-flex">
          <WifiOff className="h-3 w-3 text-navy-900" />
          <span>Offline Mode · 127.0.0.1</span>
        </Badge>

        <Badge
          variant={healthLoading ? "neutral" : isOnline ? "success" : "danger"}
          className="gap-1.5"
        >
          {isOnline ? (
            <ShieldCheck className="h-3.5 w-3.5" />
          ) : (
            <Activity className="h-3.5 w-3.5" />
          )}
          <span>
            {healthLoading
              ? "Checking Backend..."
              : isOnline
              ? "Backend Online"
              : "Backend Offline"}
          </span>
        </Badge>

        <Button
          variant="outline"
          size="sm"
          onClick={() => void refreshHealth()}
          disabled={healthLoading}
          title="Refresh backend status"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${healthLoading ? "animate-spin" : ""}`} />
          <span className="hidden sm:inline">Refresh</span>
        </Button>
      </div>
    </header>
  );
}
