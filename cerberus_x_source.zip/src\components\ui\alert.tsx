import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const alertVariants = cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm flex items-start gap-3",
  {
    variants: {
      variant: {
        info: "border-blue-200 bg-blue-50/70 text-blue-900",
        success: "border-emerald-200 bg-emerald-50/70 text-emerald-900",
        warning: "border-amber-200 bg-amber-50/80 text-amber-900",
        destructive: "border-red-200 bg-red-50/80 text-red-900",
      },
    },
    defaultVariants: {
      variant: "info",
    },
  }
);

export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {}

export function Alert({ className, variant, ...props }: AlertProps) {
  return <div role="alert" className={cn(alertVariants({ variant }), className)} {...props} />;
}
