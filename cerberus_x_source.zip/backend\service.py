"""Application service layer bridging core/pipeline with SQLite and FastAPI."""

from __future__ import annotations

import uuid
from collections import defaultdict
from pathlib import Path
from typing import Optional

from backend.database import AnalysisRepository
from backend.schemas import (
    AnalysisCounts,
    AnalysisDetailResponse,
    AnalysisListItem,
    AnalysisListResponse,
    AskResponse,
    ConflictClaimDTO,
    ConflictDTO,
    ConflictsResponse,
    DigitalTwinEntityView,
    DigitalTwinResponse,
    DocumentDTO,
    ForensicDocumentDTO,
    ForensicsResponse,
    GraphResponse,
    GraphStatistics,
    ReactFlowEdge,
    ReactFlowNode,
    ReactFlowPosition,
    UploadAnalysisResponse,
)
from core.digital_twin import DigitalTwin
from core.extractor import MAX_FILE_BYTES, save_upload
from core.graph_engine import EvidenceGraph
from core.reasoner import answer_question
from core.schemas import (
    AnalysisResult,
    Conflict,
    ConflictType,
    Severity,
    SourceDocument,
)
from pipeline import run_pipeline


class AnalysisNotFoundError(KeyError):
    """Raised when an analysis_id does not exist in SQLite."""


class InvalidUploadError(ValueError):
    """Raised when an upload request contains no valid processable files."""


def _doc_dto(doc: SourceDocument) -> DocumentDTO:
    return DocumentDTO(
        id=doc.id,
        filename=doc.filename,
        file_type=doc.file_type,
        source_type=doc.source_type,
        sha256=doc.sha256,
        extraction_method=doc.extraction_method,
        reliability=doc.reliability,
        is_suspicious=doc.is_suspicious,
        flags=doc.flags,
        warnings=doc.warnings,
        metadata=doc.metadata,
        duplicate_of=doc.duplicate_of,
        ingested_at=doc.ingested_at,
    )


def _conflict_dto(conflict: Conflict, result: AnalysisResult) -> ConflictDTO:
    claims_info: list[ConflictClaimDTO] = []
    for cid in conflict.claim_ids:
        claim = result.claim_by_id(cid)
        if claim is None:
            continue
        doc = result.doc_by_id(claim.source_id)
        claims_info.append(
            ConflictClaimDTO(
                id=claim.id,
                source_id=claim.source_id,
                source_filename=doc.filename if doc else None,
                source_label=claim.source_label,
                value=claim.value,
                unit=claim.unit,
                stage=claim.stage,
                event_time=claim.event_time,
                location=claim.location,
                locator=claim.locator,
                status=claim.status,
                reliability=doc.reliability if doc else 0.0,
                raw_text=claim.raw_text,
            )
        )
    return ConflictDTO(
        id=conflict.id,
        conflict_type=conflict.conflict_type,
        claim_ids=conflict.claim_ids,
        entity_name=conflict.entity_name,
        predicate=conflict.predicate,
        explanation=conflict.explanation,
        severity=conflict.severity,
        needs_review=conflict.needs_review,
        is_real_problem=conflict.is_real_problem,
        claims=claims_info,
    )


def _counts(result: AnalysisResult) -> AnalysisCounts:
    return AnalysisCounts(
        documents=len(result.documents),
        entities=len(result.entities),
        claims=len(result.claims),
        conflicts=len(result.conflicts),
        twin_states=len(result.twin_states),
    )


class CerberusService:
    """Orchestrates evidence ingestion, persistence, and query projections."""

    def __init__(self, repo: AnalysisRepository, upload_dir: Path) -> None:
        self.repo = repo
        self.upload_dir = Path(upload_dir)

    def _require_result(self, analysis_id: str) -> AnalysisResult:
        result = self.repo.get_analysis_result(analysis_id)
        if result is None:
            raise AnalysisNotFoundError(f"Analysis '{analysis_id}' not found.")
        return result

    def ingest_uploads(self, files: list[tuple[str, bytes]]) -> UploadAnalysisResponse:
        if not files:
            raise InvalidUploadError("At least one file must be uploaded.")

        analysis_id = f"anl_{uuid.uuid4().hex[:12]}"
        run_upload_dir = self.upload_dir / analysis_id
        saved_paths: list[Path] = []

        for filename, data in files:
            if not filename or not filename.strip():
                raise InvalidUploadError("Uploaded file is missing a filename.")
            if not data:
                raise InvalidUploadError(f"Uploaded file '{filename}' is empty.")
            if len(data) > MAX_FILE_BYTES:
                raise InvalidUploadError(
                    f"Uploaded file '{filename}' exceeds the {MAX_FILE_BYTES // (1024 * 1024)} MB limit."
                )
            saved_paths.append(save_upload(filename, data, run_upload_dir))

        result = run_pipeline(saved_paths)
        if not result.documents:
            reasons = "; ".join(result.warnings) or "No readable documents could be extracted."
            raise InvalidUploadError(reasons)

        self.repo.save_analysis(analysis_id, result)
        return UploadAnalysisResponse(
            analysis_id=analysis_id,
            created_at=result.created_at,
            counts=_counts(result),
            warnings=result.warnings,
            documents=[_doc_dto(d) for d in result.documents],
        )

    def list_analyses(self) -> AnalysisListResponse:
        rows = self.repo.list_analyses()
        items = [
            AnalysisListItem(
                analysis_id=row["analysis_id"],
                created_at=row["created_at"],
                counts=AnalysisCounts(**row["counts"]),
            )
            for row in rows
        ]
        aggregate = AnalysisCounts(
            documents=sum(item.counts.documents for item in items),
            entities=sum(item.counts.entities for item in items),
            claims=sum(item.counts.claims for item in items),
            conflicts=sum(item.counts.conflicts for item in items),
            twin_states=sum(item.counts.twin_states for item in items),
        )
        return AnalysisListResponse(
            total_investigations=len(items),
            aggregate_counts=aggregate,
            investigations=items,
        )

    def get_analysis(self, analysis_id: str) -> AnalysisDetailResponse:
        result = self._require_result(analysis_id)
        return AnalysisDetailResponse(
            analysis_id=analysis_id,
            created_at=result.created_at,
            counts=_counts(result),
            documents=[_doc_dto(d) for d in result.documents],
            entities=result.entities,
            claims=result.claims,
            conflicts=[_conflict_dto(c, result) for c in result.conflicts],
            twin_states=result.twin_states,
            warnings=result.warnings,
        )

    def get_graph(self, analysis_id: str) -> GraphResponse:
        result = self._require_result(analysis_id)
        engine = EvidenceGraph()
        engine.build(result)
        nx_graph = engine.graph

        column_x = {
            "document": 40.0,
            "claim": 380.0,
            "entity": 740.0,
            "conflict": 1080.0,
        }
        row_counters: dict[str, int] = defaultdict(int)
        nodes: list[ReactFlowNode] = []

        for node_id, attrs in nx_graph.nodes(data=True):
            ntype = attrs.get("node_type", "unknown")
            idx = row_counters[ntype]
            row_counters[ntype] += 1
            x = column_x.get(ntype, 0.0)
            y = 40.0 + idx * 120.0
            nodes.append(
                ReactFlowNode(
                    id=str(node_id),
                    type=ntype,
                    position=ReactFlowPosition(x=x, y=y),
                    data={
                        "label": attrs.get("label", str(node_id)),
                        "nodeType": ntype,
                        **{k: v for k, v in attrs.items() if k not in ("node_type", "label")},
                    },
                )
            )

        edges: list[ReactFlowEdge] = []
        for idx, (src, dst, attrs) in enumerate(nx_graph.edges(data=True)):
            relation = attrs.get("relation", "RELATED_TO")
            edges.append(
                ReactFlowEdge(
                    id=f"edge_{idx}_{src}_{dst}",
                    source=str(src),
                    target=str(dst),
                    label=relation,
                    animated=(relation == "PARTICIPATES_IN"),
                    data={"relation": relation},
                )
            )

        return GraphResponse(
            analysis_id=analysis_id,
            nodes=nodes,
            edges=edges,
            statistics=GraphStatistics(**engine.statistics()),
        )

    def get_conflicts(
        self,
        analysis_id: str,
        *,
        conflict_type: Optional[ConflictType] = None,
        severity: Optional[Severity] = None,
        only_real_problems: bool = False,
    ) -> ConflictsResponse:
        result = self._require_result(analysis_id)
        items = [_conflict_dto(c, result) for c in result.conflicts]
        if conflict_type is not None:
            items = [c for c in items if c.conflict_type == conflict_type]
        if severity is not None:
            items = [c for c in items if c.severity == severity]
        if only_real_problems:
            items = [c for c in items if c.is_real_problem]

        real_count = sum(1 for c in result.conflicts if c.is_real_problem)
        return ConflictsResponse(
            analysis_id=analysis_id,
            total=len(items),
            real_problem_count=real_count,
            conflicts=items,
        )

    def get_digital_twin(
        self,
        analysis_id: str,
        *,
        entity_id: Optional[str] = None,
    ) -> DigitalTwinResponse:
        result = self._require_result(analysis_id)
        twin = DigitalTwin(result)

        entities_by_id = {e.id: e for e in result.entities}
        grouped: dict[str, list] = defaultdict(list)
        for state in twin.states:
            if entity_id and state.entity_id != entity_id:
                continue
            grouped[state.entity_id].append(state)

        entity_views: list[DigitalTwinEntityView] = []
        for eid, states in grouped.items():
            ent = entities_by_id.get(eid)
            attrs = sorted({s.attribute for s in states})
            current_attributes = {}
            for attr in attrs:
                latest = twin.get_entity_state(eid, attr)
                if latest is not None:
                    current_attributes[attr] = latest
            entity_views.append(
                DigitalTwinEntityView(
                    entity_id=eid,
                    canonical_name=ent.canonical_name if ent else states[0].entity_name,
                    entity_type=ent.entity_type if ent else "unknown",
                    aliases=ent.aliases if ent else [],
                    states=states,
                    current_attributes=current_attributes,
                )
            )

        filtered_states = (
            [s for s in twin.states if s.entity_id == entity_id]
            if entity_id
            else twin.states
        )

        return DigitalTwinResponse(
            analysis_id=analysis_id,
            summary=twin.summary(),
            entities=entity_views,
            states=filtered_states,
        )

    def ask(self, analysis_id: str, question: str) -> AskResponse:
        result = self._require_result(analysis_id)
        ans = answer_question(question, result)
        return AskResponse(
            analysis_id=analysis_id,
            question=ans.question,
            status=ans.status,
            answer_text=ans.answer_text,
            confidence=ans.confidence,
            citations=ans.citations,
            conflict_ids=ans.conflict_ids,
            used_llm=ans.used_llm,
            notes=ans.notes,
        )

    def get_forensics(self, analysis_id: str) -> ForensicsResponse:
        result = self._require_result(analysis_id)
        docs = [
            ForensicDocumentDTO(
                id=d.id,
                filename=d.filename,
                file_type=d.file_type,
                source_type=d.source_type,
                sha256=d.sha256,
                extraction_method=d.extraction_method,
                reliability=d.reliability,
                is_suspicious=d.is_suspicious,
                flags=d.flags,
                warnings=d.warnings,
                metadata=d.metadata,
                raw_text=d.text,
            )
            for d in result.documents
        ]
        return ForensicsResponse(
            analysis_id=analysis_id,
            total_documents=len(docs),
            suspicious_documents=sum(1 for d in docs if d.is_suspicious),
            total_flags=sum(len(d.flags) for d in docs),
            documents=docs,
        )
