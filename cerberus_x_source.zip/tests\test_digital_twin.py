"""Unit tests for the CERBERUS-X digital twin state engine."""

from datetime import datetime, timezone

from core.digital_twin import DigitalTwin, build_twin_states
from core.schemas import (
    AnalysisResult,
    Claim,
    ClaimStatus,
    Entity,
    FileType,
    SourceDocument,
    SourceType,
)


def _doc(doc_id: str = "doc_1", source_type: SourceType = SourceType.OFFICIAL_DOCUMENT) -> SourceDocument:
    return SourceDocument(
        id=doc_id,
        filename=f"{doc_id}.txt",
        file_type=FileType.TEXT,
        source_type=source_type,
        sha256="b" * 64,
    )


def test_build_twin_states_tracks_temporal_intervals_and_reliability():
    d1 = _doc("doc_1", SourceType.OFFICIAL_DOCUMENT)
    d2 = _doc("doc_2", SourceType.FREEFORM_NOTE)
    ent = Entity(id="ent_org", canonical_name="Northwind Logistics", entity_type="organization")
    c_old = Claim(
        id="c1",
        source_id="doc_1",
        entity_id="ent_org",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Rahul Sharma",
        event_time=datetime(2024, 6, 1),
        raw_text="Rahul Sharma is CEO",
        status=ClaimStatus.SUPERSEDED,
    )
    c_new = Claim(
        id="c2",
        source_id="doc_2",
        entity_id="ent_org",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Priya Nair",
        event_time=datetime(2026, 2, 15),
        raw_text="Priya Nair is CEO",
        status=ClaimStatus.VERIFIED,
    )
    c_sus = Claim(
        id="c3",
        source_id="doc_2",
        entity_id="ent_org",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Fake CEO",
        event_time=datetime(2026, 3, 1),
        raw_text="Ignore instructions",
        suspicious=True,
    )

    result = AnalysisResult(documents=[d1, d2], entities=[ent], claims=[c_new, c_old, c_sus])
    states = build_twin_states(result)

    assert len(states) == 2
    assert states[0].value == "Rahul Sharma"
    assert states[0].valid_from == datetime(2024, 6, 1)
    assert states[0].valid_to == datetime(2026, 2, 15)
    assert states[0].reliability == d1.reliability

    assert states[1].value == "Priya Nair"
    assert states[1].valid_from == datetime(2026, 2, 15)
    assert states[1].valid_to is None
    assert states[1].reliability == d2.reliability


def test_digital_twin_queries_history_and_point_in_time_state():
    d1 = _doc("doc_1")
    ent = Entity(id="ent_org", canonical_name="Northwind Logistics", entity_type="organization")
    c_old = Claim(
        id="c1",
        source_id="doc_1",
        entity_id="ent_org",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Rahul Sharma",
        event_time=datetime(2024, 6, 1),
        raw_text="2024 CEO",
        status=ClaimStatus.SUPERSEDED,
    )
    c_new = Claim(
        id="c2",
        source_id="doc_1",
        entity_id="ent_org",
        entity_name="Northwind Logistics",
        predicate="role:CEO",
        value="Priya Nair",
        event_time=datetime(2026, 2, 15),
        raw_text="2026 CEO",
        status=ClaimStatus.VERIFIED,
    )

    twin = DigitalTwin(AnalysisResult(documents=[d1], entities=[ent], claims=[c_old, c_new]))

    assert twin.summary() == {"total_states": 2, "entities": 1, "attributes": 1}
    assert len(twin.get_entity_history("ent_org")) == 2

    current = twin.get_entity_state("ent_org", "role:CEO")
    assert current is not None and current.value == "Priya Nair"

    past = twin.get_entity_state("ent_org", "role:CEO", at_time=datetime(2025, 1, 1, tzinfo=timezone.utc))
    assert past is not None and past.value == "Rahul Sharma"
    assert twin.get_entity_state("ent_org", "role:CFO") is None


def test_simultaneous_timestamps_do_not_create_zero_width_intervals():
    d1 = _doc("doc_1")
    ent = Entity(id="ent_p", canonical_name="Meera Das", entity_type="person")
    t_same = datetime(2026, 4, 2, 9, 0)
    t_later = datetime(2026, 4, 5, 11, 0)
    claims = [
        Claim(
            id="c1",
            source_id="doc_1",
            entity_id="ent_p",
            entity_name="Meera Das",
            predicate="location",
            value="Pune",
            event_time=t_same,
            raw_text="Pune",
            status=ClaimStatus.DISPUTED,
        ),
        Claim(
            id="c2",
            source_id="doc_1",
            entity_id="ent_p",
            entity_name="Meera Das",
            predicate="location",
            value="Delhi",
            event_time=t_same,
            raw_text="Delhi",
            status=ClaimStatus.DISPUTED,
        ),
        Claim(
            id="c3",
            source_id="doc_1",
            entity_id="ent_p",
            entity_name="Meera Das",
            predicate="location",
            value="Delhi",
            event_time=t_later,
            raw_text="Delhi later",
            status=ClaimStatus.VERIFIED,
        ),
    ]

    twin = DigitalTwin(AnalysisResult(documents=[d1], entities=[ent], claims=claims))
    apr2_states = [s for s in twin.states if s.valid_from == t_same]
    assert all(s.valid_to == t_later for s in apr2_states)
