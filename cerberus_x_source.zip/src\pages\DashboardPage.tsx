import * as React from "react";
import {
  Activity,
  AlertTriangle,
  BrainCircuit,
  CheckCircle2,
  ChevronRight,
  Database,
  FileSearch,
  FileText,
  GitBranch,
  GitCompare,
  HardDrive,
  History,
  Network,
  ScanSearch,
  ShieldCheck,
  ShieldAlert,
  UploadCloud,
  Users,
  Zap,
} from "lucide-react";

import { useAnalysis } from "@/context/AnalysisContext";
import { useNotifications } from "@/context/NotificationContext";

import {
  API_BASE_URL,
  uploadEvidenceFiles,
  askAnalysisQuestion,
  extractApiError,
} from "@/lib/api";

import type { AskResponse } from "@/types/cerberus";

export function DashboardPage() {
  const {
    health,
    healthLoading,
    healthError,
    refreshHealth,
    activeAnalysisId,
    activeAnalysis,
    analysisLoading,
    history,
    selectAnalysis,
  } = useAnalysis();

  const { notify } = useNotifications();

  // Investigation search
  const [lookupId, setLookupId] = React.useState(
    activeAnalysisId ?? ""
  );

  // AI Question Answering
  const [question, setQuestion] = React.useState("");
  const [askingQuestion, setAskingQuestion] = React.useState(false);
  const [askResult, setAskResult] = React.useState<AskResponse | null>(
    null
  );
  const [askError, setAskError] = React.useState("");

  // Document upload
  const [selectedFiles, setSelectedFiles] = React.useState<File[]>([]);
  const [uploading, setUploading] = React.useState(false);
  const [uploadProgress, setUploadProgress] = React.useState(0);

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Keep investigation ID synchronized
  React.useEffect(() => {
    if (activeAnalysisId) {
      setLookupId(activeAnalysisId);
    }
  }, [activeAnalysisId]);

  // Clear previous answers when switching investigations
  React.useEffect(() => {
    setAskResult(null);
    setAskError("");
  }, [activeAnalysisId]);

  // ----------------------------------
  // DOCUMENT UPLOAD
  // ----------------------------------

  const handleUpload = async () => {
    if (selectedFiles.length === 0 || uploading) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      const result = await uploadEvidenceFiles(
        selectedFiles,
        setUploadProgress
      );

      const loaded = await selectAnalysis(result.analysis_id);

      if (!loaded) {
        throw new Error(
          "Upload completed, but the investigation could not be loaded."
        );
      }

      notify(
        "success",
        "Analysis completed",
        `${result.counts.documents} document(s) processed successfully.`
      );

      setSelectedFiles([]);
      setUploadProgress(100);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      notify(
        "error",
        "Upload failed",
        extractApiError(error)
      );
    } finally {
      setUploading(false);
    }
  };

  // ----------------------------------
  // AI QUESTION ANSWERING
  // ----------------------------------

  const handleAskQuestion = async (
    e: React.FormEvent<HTMLFormElement>
  ) => {
    e.preventDefault();

    const trimmedQuestion = question.trim();

    if (!trimmedQuestion) {
      setAskError("Please enter a question.");
      return;
    }

    if (!activeAnalysisId) {
      setAskError(
        "Please upload documents or load an investigation first."
      );

      notify(
        "warning",
        "No investigation selected",
        "Load an investigation before asking questions."
      );

      return;
    }

    if (askingQuestion) return;

    setAskingQuestion(true);
    setAskError("");
    setAskResult(null);

    try {
      // Send the question to the FastAPI backend
      const result = await askAnalysisQuestion(
        activeAnalysisId,
        trimmedQuestion
      );

      setAskResult(result);

      notify(
        "success",
        "Answer generated",
        "Your question was processed using the investigation evidence."
      );
    } catch (error) {
      const message = extractApiError(error);

      setAskError(message);

      notify(
        "error",
        "Question failed",
        message
      );
    } finally {
      setAskingQuestion(false);
    }
  };

  // ----------------------------------
  // LOAD INVESTIGATION
  // ----------------------------------

  const loadInvestigation = async (
    e: React.FormEvent<HTMLFormElement>
  ) => {
    e.preventDefault();

    if (!lookupId.trim()) {
      notify(
        "warning",
        "Analysis ID required",
        "Enter an investigation ID."
      );
      return;
    }

    const success = await selectAnalysis(lookupId.trim());

    if (success) {
      notify(
        "success",
        "Investigation loaded",
        "Local SQLite data loaded."
      );
    } else {
      notify(
        "error",
        "Not found",
        "Could not find this investigation."
      );
    }
  };

  // ----------------------------------
  // DASHBOARD NAVIGATION
  // ----------------------------------

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  // ----------------------------------
  // STATISTICS
  // ----------------------------------

  const counts = activeAnalysis?.counts;

  const suspiciousDocs =
    activeAnalysis?.documents.filter(
      (doc) => doc.is_suspicious
    ).length ?? 0;

  // ----------------------------------
  // MODALITY DISTRIBUTION
  // ----------------------------------

  const modalityCounts = React.useMemo(() => {
    const map = new Map<string, number>();

    for (const doc of activeAnalysis?.documents ?? []) {
      map.set(
        doc.file_type,
        (map.get(doc.file_type) ?? 0) + 1
      );
    }

    return Array.from(map.entries());
  }, [activeAnalysis]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">

      {/* HEADER */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center justify-between gap-4 px-6 py-4">

          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-navy-950 text-white">
              <FileSearch size={23} />
            </div>

            <div>
              <h1 className="text-xl font-bold tracking-tight text-navy-950">
                CERBERUS-X
              </h1>

              <p className="text-xs text-slate-500">
                Multimodal Evidence Intelligence
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">

            <span className="flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-600">
              <Database size={14} />
              LOCAL SQLITE
            </span>

            <span
              className={`flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold ${
                health
                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                  : "border-amber-200 bg-amber-50 text-amber-700"
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-current" />

              {healthLoading
                ? "CHECKING"
                : health
                  ? "BACKEND ONLINE"
                  : "BACKEND OFFLINE"}
            </span>

            <button
              type="button"
              onClick={() => void refreshHealth()}
              className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50"
            >
              Refresh
            </button>

          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1500px] space-y-8 px-6 py-8">

        {/* INTRO */}
        <section className="flex flex-col justify-between gap-5 lg:flex-row lg:items-center">

          <div>
            <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-blue-700">
              <Zap size={14} />
              Offline Intelligence Platform
            </div>

            <h2 className="text-3xl font-bold tracking-tight text-navy-950">
              Evidence Intelligence Dashboard
            </h2>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
              Analyze documents, connect multimodal evidence,
              discover contradictions and generate traceable
              intelligence. Everything stays on your local machine.
            </p>
          </div>

          <form
            onSubmit={loadInvestigation}
            className="flex flex-wrap gap-2"
          >
            <input
              value={lookupId}
              onChange={(e) => setLookupId(e.target.value)}
              placeholder="Enter Investigation ID"
              className="h-10 min-w-[220px] rounded-lg border border-slate-200 bg-white px-3 text-sm outline-none focus:border-blue-500"
            />

            <button
              type="submit"
              disabled={analysisLoading}
              className="rounded-lg bg-navy-950 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-900 disabled:opacity-50"
            >
              {analysisLoading ? "Loading..." : "Load"}
            </button>
          </form>

        </section>

        {/* BACKEND ERROR */}
        {healthError && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-4">

            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle size={18} />

              <p className="text-sm font-semibold">
                Backend Connection Error
              </p>
            </div>

            <p className="mt-2 text-sm text-red-600">
              {healthError}
            </p>

          </div>
        )}

        {/* STATISTICS */}
        <section>

          <div className="mb-4">
            <h3 className="text-lg font-bold text-navy-950">
              Intelligence Overview
            </h3>

            <p className="text-sm text-slate-500">
              {activeAnalysis
                ? `Investigation: ${activeAnalysis.analysis_id}`
                : "Load an investigation to view its analysis statistics."}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">

            {[
              {
                label: "Documents",
                value: counts?.documents,
                icon: FileText,
              },
              {
                label: "Entities",
                value: counts?.entities,
                icon: Users,
              },
              {
                label: "Claims",
                value: counts?.claims,
                icon: Network,
              },
              {
                label: "Conflicts",
                value: counts?.conflicts,
                icon: GitCompare,
              },
              {
                label: "Twin States",
                value: counts?.twin_states,
                icon: Activity,
              },
            ].map((item) => {
              const Icon = item.icon;

              return (
                <div
                  key={item.label}
                  className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
                >
                  <div className="flex items-center justify-between">

                    <p className="text-sm font-medium text-slate-500">
                      {item.label}
                    </p>

                    <div className="rounded-lg bg-slate-100 p-2 text-blue-700">
                      <Icon size={19} />
                    </div>

                  </div>

                  <h3 className="mt-4 text-3xl font-bold text-navy-950">
                    {item.value ?? "—"}
                  </h3>

                  <p className="mt-1 text-xs text-slate-400">
                    {activeAnalysis
                      ? "Current investigation"
                      : "Awaiting data"}
                  </p>

                </div>
              );
            })}

          </div>
        </section>

        {/* FEATURE NAVIGATION */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">

          <h3 className="mb-4 text-base font-bold text-navy-950">
            Investigation Workspace
          </h3>

          <div className="flex flex-wrap gap-2">
            {[
              ["Upload Documents", "upload"],
              ["Evidence Graph", "graph"],
              ["Conflict Detection", "conflicts"],
              ["Digital Twin", "twin"],
              ["AI Question Answering", "ask"],
              ["Forensic Inspector", "forensics"],
            ].map(([label, id]) => (
              <button
                key={id}
                type="button"
                onClick={() => scrollTo(id)}
                className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700"
              >
                {label}
                <ChevronRight className="ml-1 inline" size={14} />
              </button>
            ))}
          </div>

        </section>

        {/* DOCUMENT UPLOAD */}
        <section id="upload" className="scroll-mt-24">

          <div className="mb-4">
            <h3 className="text-lg font-bold text-navy-950">
              Document Ingestion
            </h3>

            <p className="text-sm text-slate-500">
              Upload multiple evidence formats into one investigation.
            </p>
          </div>

          <div className="rounded-xl border-2 border-dashed border-blue-200 bg-white px-6 py-10 text-center shadow-sm">

            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
              <UploadCloud size={28} />
            </div>

            <h4 className="mt-4 font-semibold text-navy-950">
              Upload your evidence documents
            </h4>

            <p className="mt-2 text-sm text-slate-500">
              Select one or multiple files for analysis.
            </p>

            <p className="mt-1 text-xs text-slate-400">
              PDF, DOCX, DOC, TXT, PNG, JPG, TIFF, CSV, XLSX, XLS, JSON and XML
            </p>

            {/* FILE INPUT */}
            <div className="mt-6 flex justify-center">

              <input
                ref={fileInputRef}
                type="file"
                multiple
                disabled={uploading}
                accept=".pdf,.docx,.doc,.txt,.png,.jpg,.jpeg,.tiff,.tif,.csv,.xlsx,.xls,.json,.xml"
                onChange={(e) => {
                  setSelectedFiles(
                    Array.from(e.target.files ?? [])
                  );
                }}
                className="block w-full max-w-lg cursor-pointer rounded-lg border border-slate-200 bg-white p-3 text-sm text-slate-600 file:mr-4 file:cursor-pointer file:rounded-lg file:border-0 file:bg-blue-700 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-blue-800"
              />

            </div>

            {/* SELECTED FILES */}
            {selectedFiles.length > 0 && (

              <div className="mx-auto mt-6 max-w-xl text-left">

                <div className="mb-3 flex items-center justify-between">

                  <h5 className="text-sm font-semibold text-slate-700">
                    Selected Files ({selectedFiles.length})
                  </h5>

                  <button
                    type="button"
                    disabled={uploading}
                    onClick={() => {
                      setSelectedFiles([]);

                      if (fileInputRef.current) {
                        fileInputRef.current.value = "";
                      }
                    }}
                    className="text-xs font-medium text-red-600 hover:text-red-700 disabled:opacity-50"
                  >
                    Clear All
                  </button>

                </div>

                <div className="space-y-2">

                  {selectedFiles.map((file, index) => (

                    <div
                      key={`${file.name}-${index}`}
                      className="flex items-center justify-between gap-3 rounded-lg bg-slate-50 p-3"
                    >

                      <div className="flex min-w-0 items-center gap-3">

                        <FileText
                          size={18}
                          className="shrink-0 text-blue-700"
                        />

                        <div className="min-w-0">

                          <p className="truncate text-sm font-medium text-slate-700">
                            {file.name}
                          </p>

                          <p className="text-xs text-slate-400">
                            {(file.size / 1024).toFixed(1)} KB
                          </p>

                        </div>

                      </div>

                      <button
                        type="button"
                        disabled={uploading}
                        onClick={() => {
                          setSelectedFiles((previous) =>
                            previous.filter((_, i) => i !== index)
                          );
                        }}
                        className="shrink-0 text-sm font-medium text-red-500 hover:text-red-700 disabled:opacity-50"
                      >
                        Remove
                      </button>

                    </div>

                  ))}

                </div>

                {/* UPLOAD PROGRESS */}
                {uploading && (

                  <div className="mt-5">

                    <div className="mb-2 flex justify-between text-xs text-slate-500">
                      <span>Uploading documents...</span>
                      <span>{uploadProgress}%</span>
                    </div>

                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">

                      <div
                        className="h-full rounded-full bg-blue-600 transition-all duration-300"
                        style={{
                          width: `${uploadProgress}%`,
                        }}
                      />

                    </div>

                    <p className="mt-2 text-xs text-slate-400">
                      Please wait while the server processes your evidence.
                    </p>

                  </div>

                )}

                {/* UPLOAD BUTTON */}
                <button
                  type="button"
                  onClick={handleUpload}
                  disabled={uploading || selectedFiles.length === 0}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-blue-700 px-5 py-3 text-sm font-semibold text-white transition hover:bg-blue-800 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <UploadCloud size={18} />

                  {uploading
                    ? "Analyzing Documents..."
                    : "Upload & Analyze"}

                </button>

              </div>

            )}

          </div>

          {/* PROCESSED DOCUMENTS */}
          {activeAnalysis && (

            <div className="mt-4 rounded-xl border border-slate-200 bg-white p-5">

              <h4 className="font-semibold text-navy-950">
                Processed Documents
              </h4>

              <div className="mt-3 space-y-2">

                {activeAnalysis.documents.map((doc, index) => (

                  <div
                    key={index}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-slate-50 p-3"
                  >

                    <div className="flex items-center gap-3">

                      <FileText
                        className="text-blue-700"
                        size={19}
                      />

                      <div>

                        <p className="text-sm font-medium">
                          {doc.filename}
                        </p>

                        <p className="text-xs text-slate-500">
                          {doc.file_type.toUpperCase()} · {doc.extraction_method}
                        </p>

                      </div>

                    </div>

                    <span
                      className={`text-xs font-semibold ${
                        doc.is_suspicious
                          ? "text-red-600"
                          : "text-emerald-600"
                      }`}
                    >
                      {doc.is_suspicious
                        ? "Flagged"
                        : "Processed"}
                    </span>

                  </div>

                ))}

              </div>

            </div>

          )}

        </section>

        {/* EVIDENCE GRAPH */}
        <section id="graph" className="scroll-mt-24">

          <SectionHeading
            icon={<GitBranch size={20} />}
            title="Multimodal Evidence Graph"
            description="Connect documents, entities, claims and evidence relationships."
          />

          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">

            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">

              {[
                ["Documents", counts?.documents],
                ["Entities", counts?.entities],
                ["Claims", counts?.claims],
                ["Conflicts", counts?.conflicts],
              ].map(([label, value]) => (

                <div
                  key={String(label)}
                  className="rounded-lg bg-slate-50 p-4"
                >
                  <p className="text-xs text-slate-500">
                    {label}
                  </p>

                  <p className="mt-2 text-2xl font-bold text-navy-950">
                    {value ?? "—"}
                  </p>
                </div>

              ))}

            </div>

            <div className="mt-5 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-8 text-center">

              <Network
                className="mx-auto text-blue-600"
                size={32}
              />

              <p className="mt-3 font-semibold text-navy-950">
                Interactive Evidence Graph
              </p>

              <p className="mt-1 text-sm text-slate-500">
                React Flow visualization will display actual evidence relationships.
              </p>

            </div>

          </div>

        </section>

        {/* CONFLICT DETECTION */}
        <section id="conflicts" className="scroll-mt-24">

          <SectionHeading
            icon={<GitCompare size={20} />}
            title="Conflict Detection"
            description="Identify contradictory claims and compare their supporting evidence."
          />

          <div className="grid gap-4 md:grid-cols-2">

            {activeAnalysis?.conflicts.length ? (

              activeAnalysis.conflicts.map((conflict, index) => (

                <div
                  key={index}
                  className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
                >

                  <div className="flex items-center justify-between gap-3">

                    <span className="font-semibold text-navy-950">
                      {conflict.entity_name}
                    </span>

                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        conflict.is_real_problem
                          ? "bg-red-50 text-red-700"
                          : "bg-amber-50 text-amber-700"
                      }`}
                    >
                      {conflict.is_real_problem
                        ? "Contradiction"
                        : "Temporal note"}
                    </span>

                  </div>

                  <p className="mt-3 text-sm leading-6 text-slate-600">
                    {conflict.explanation}
                  </p>

                </div>

              ))

            ) : (

              <EmptyCard text="Load an investigation to inspect detected conflicts." />

            )}

          </div>

        </section>

        {/* DIGITAL TWIN */}
        <section id="twin" className="scroll-mt-24">

          <SectionHeading
            icon={<History size={20} />}
            title="Digital Twin"
            description="Track entity states and historical changes over time."
          />

          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

              <div>

                <p className="text-sm text-slate-500">
                  Tracked state records
                </p>

                <p className="mt-1 text-3xl font-bold text-navy-950">
                  {counts?.twin_states ?? "—"}
                </p>

              </div>

              <div className="rounded-lg bg-indigo-50 p-3 text-indigo-700">
                <History size={28} />
              </div>

            </div>

            <p className="mt-4 text-sm text-slate-500">
              Historical state visualization and attribute timelines will be connected to the digital twin API.
            </p>

          </div>

        </section>

        {/* AI QUESTION ANSWERING */}
        <section id="ask" className="scroll-mt-24">

          <SectionHeading
            icon={<BrainCircuit size={20} />}
            title="AI Question Answering"
            description="Ask questions and receive answers grounded in local evidence."
          />

          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">

            <div className="flex items-start gap-3">

              <div className="rounded-lg bg-blue-50 p-3 text-blue-700">
                <BrainCircuit size={23} />
              </div>

              <div>

                <h4 className="font-semibold text-navy-950">
                  Ask your investigation
                </h4>

                <p className="mt-1 text-sm text-slate-500">
                  Answers are requested from the local reasoning engine using the selected investigation.
                </p>

              </div>

            </div>

            {/* CURRENT INVESTIGATION */}
            <div className="mt-4 rounded-lg bg-slate-50 p-3">

              <p className="text-xs font-medium text-slate-500">
                ACTIVE INVESTIGATION
              </p>

              <p className="mt-1 break-all text-sm font-semibold text-navy-950">
                {activeAnalysisId ?? "No investigation selected"}
              </p>

            </div>

            {/* QUESTION FORM */}
            <form
              className="mt-5 flex flex-col gap-3 sm:flex-row"
              onSubmit={handleAskQuestion}
            >

              <input
                value={question}
                onChange={(e) => {
                  setQuestion(e.target.value);
                  setAskError("");
                }}
                placeholder="Ask something about the evidence..."
                disabled={askingQuestion}
                className="h-11 flex-1 rounded-lg border border-slate-200 px-4 text-sm outline-none focus:border-blue-500 disabled:bg-slate-50"
              />

              <button
                type="submit"
                disabled={
                  !question.trim() ||
                  !activeAnalysisId ||
                  askingQuestion
                }
                className="flex items-center justify-center gap-2 rounded-lg bg-navy-950 px-6 py-3 text-sm font-semibold text-white hover:bg-blue-900 disabled:cursor-not-allowed disabled:opacity-40"
              >

                {askingQuestion ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <BrainCircuit size={17} />
                    Ask Question
                  </>
                )}

              </button>

            </form>

            {/* NO INVESTIGATION WARNING */}
            {!activeAnalysisId && (
              <p className="mt-3 text-xs text-amber-600">
                Upload evidence or load an existing investigation before asking questions.
              </p>
            )}

            {/* QUESTION ERROR */}
            {askError && (

              <div className="mt-5 rounded-lg border border-red-200 bg-red-50 p-4">

                <div className="flex items-center gap-2 text-red-700">
                  <AlertTriangle size={17} />

                  <p className="text-sm font-semibold">
                    Unable to generate answer
                  </p>
                </div>

                <p className="mt-2 text-sm text-red-600">
                  {askError}
                </p>

              </div>

            )}

            {/* ANSWER RESULT */}
            {askResult && (

              <div className="mt-6 rounded-xl border border-emerald-200 bg-emerald-50/50 p-5">

                <div className="flex items-center gap-2">

                  <CheckCircle2
                    size={20}
                    className="text-emerald-600"
                  />

                  <h4 className="font-bold text-emerald-900">
                    Answer Generated
                  </h4>

                </div>

                <div className="mt-4 rounded-lg border border-emerald-100 bg-white p-4">

                  <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500">
                    Local Reasoning Engine Response
                  </p>

                  <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-7 text-slate-700">
                    {JSON.stringify(askResult, null, 2)}
                  </pre>

                </div>

                <p className="mt-3 text-xs text-slate-500">
                  The response above contains the data returned by your backend.
                  Check its evidence references and conflict information.
                </p>

                <button
                  type="button"
                  onClick={() => {
                    setAskResult(null);
                    setQuestion("");
                    setAskError("");
                  }}
                  className="mt-4 rounded-lg border border-emerald-200 bg-white px-4 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-50"
                >
                  Clear Answer
                </button>

              </div>

            )}

          </div>

        </section>

        {/* FORENSIC INSPECTOR */}
        <section id="forensics" className="scroll-mt-24">

          <SectionHeading
            icon={<ShieldCheck size={20} />}
            title="Forensic Inspector"
            description="Inspect document integrity, suspicious content and source reliability."
          />

          <div className="grid gap-4 md:grid-cols-3">

            <InfoCard
              icon={<ShieldAlert size={22} />}
              title="Suspicious Documents"
              value={activeAnalysis ? suspiciousDocs : "—"}
              description="Documents flagged by local analysis."
            />

            <InfoCard
              icon={<ScanSearch size={22} />}
              title="Security Inspection"
              value={
                health?.ocr_available
                  ? "OCR Ready"
                  : "OCR Unavailable"
              }
              description="Local OCR system availability."
            />

            <InfoCard
              icon={<HardDrive size={22} />}
              title="Local Storage"
              value="SQLite"
              description="Investigation data stored locally."
            />

          </div>

        </section>

        {/* MODALITY AND SYSTEM STATUS */}
        <section className="grid gap-5 lg:grid-cols-2">

          {/* MODALITY */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">

            <h3 className="font-bold text-navy-950">
              Modality Distribution
            </h3>

            <p className="mt-1 text-xs text-slate-500">
              Actual document formats in this investigation.
            </p>

            {modalityCounts.length ? (

              <div className="mt-5 space-y-4">

                {modalityCounts.map(([type, value]) => {

                  const total =
                    activeAnalysis?.documents.length ?? 0;

                  const percent =
                    total ? (value / total) * 100 : 0;

                  return (

                    <div key={type}>

                      <div className="mb-1 flex justify-between text-sm">

                        <span className="font-medium text-slate-700">
                          {type.toUpperCase()}
                        </span>

                        <span className="text-slate-500">
                          {value}
                        </span>

                      </div>

                      <div className="h-2 overflow-hidden rounded-full bg-slate-100">

                        <div
                          className="h-full rounded-full bg-blue-600"
                          style={{
                            width: `${percent}%`,
                          }}
                        />

                      </div>

                    </div>

                  );

                })}

              </div>

            ) : (

              <EmptyCard text="Modality information will appear after loading an investigation." />

            )}

          </div>

          {/* SYSTEM INFORMATION */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">

            <h3 className="font-bold text-navy-950">
              System Information
            </h3>

            <div className="mt-5 space-y-4">

              <StatusRow
                icon={<Activity size={18} />}
                label="Backend API"
                value={health ? "Connected" : "Disconnected"}
                good={Boolean(health)}
              />

              <StatusRow
                icon={<Database size={18} />}
                label="Database"
                value={health?.database ?? "SQLite"}
                good
              />

              <StatusRow
                icon={<ScanSearch size={18} />}
                label="Local OCR"
                value={
                  health?.ocr_available
                    ? "Available"
                    : "Unavailable"
                }
                good={Boolean(health?.ocr_available)}
              />

              <StatusRow
                icon={<ShieldCheck size={18} />}
                label="Storage Mode"
                value="Local"
                good
              />

              {health?.ocr_message && (

                <p className="text-xs leading-5 text-slate-500">
                  {health.ocr_message}
                </p>

              )}

            </div>

          </div>

        </section>

        {/* RECENT INVESTIGATIONS */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">

          <h3 className="font-bold text-navy-950">
            Recent Investigations
          </h3>

          <p className="mt-1 text-xs text-slate-500">
            Investigations opened in this browser session history.
          </p>

          <div className="mt-4 space-y-2">

            {history.length ? (

              history.map((item) => (

                <button
                  key={item.analysis_id}
                  type="button"
                  onClick={() => void selectAnalysis(item.analysis_id)}
                  className="flex w-full flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-100 p-4 text-left transition hover:bg-slate-50"
                >

                  <div>

                    <p className="text-sm font-semibold text-navy-950">
                      {item.analysis_id}
                    </p>

                    <p className="mt-1 text-xs text-slate-500">
                      {item.documents} documents · {item.claims} claims · {item.conflicts} conflicts
                    </p>

                  </div>

                  <ChevronRight
                    className="text-slate-400"
                    size={18}
                  />

                </button>

              ))

            ) : (

              <p className="py-5 text-center text-sm text-slate-400">
                No investigation history available.
              </p>

            )}

          </div>

        </section>

        {/* FOOTER */}
        <footer className="border-t border-slate-200 py-6 text-center">

          <p className="text-sm font-bold tracking-wider text-navy-950">
            CERBERUS-X
          </p>

          <p className="mt-1 text-xs text-slate-500">
            Multimodal Evidence Intelligence · Local Processing · Traceable Reasoning
          </p>

          <p className="mt-2 text-xs text-slate-400">
            Backend: {API_BASE_URL}
          </p>

        </footer>

      </main>

    </div>
  );
}

// ----------------------------------
// SECTION HEADING
// ----------------------------------

function SectionHeading({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="mb-4">

      <div className="flex items-center gap-2">

        <span className="text-blue-700">
          {icon}
        </span>

        <h3 className="text-lg font-bold text-navy-950">
          {title}
        </h3>

      </div>

      <p className="mt-1 text-sm text-slate-500">
        {description}
      </p>

    </div>
  );
}

// ----------------------------------
// EMPTY CARD
// ----------------------------------

function EmptyCard({ text }: { text: string }) {
  return (
    <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-500">
      {text}
    </div>
  );
}

// ----------------------------------
// INFORMATION CARD
// ----------------------------------

function InfoCard({
  icon,
  title,
  value,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  description: string;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">

      <div className="text-blue-700">
        {icon}
      </div>

      <p className="mt-4 text-sm text-slate-500">
        {title}
      </p>

      <h4 className="mt-1 text-xl font-bold text-navy-950">
        {value}
      </h4>

      <p className="mt-1 text-xs text-slate-400">
        {description}
      </p>

    </div>
  );
}

// ----------------------------------
// STATUS ROW
// ----------------------------------

function StatusRow({
  icon,
  label,
  value,
  good,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  good: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3">

      <span className="flex items-center gap-2 text-sm text-slate-600">
        {icon}
        {label}
      </span>

      <span
        className={`flex items-center gap-1.5 text-xs font-semibold ${
          good
            ? "text-emerald-600"
            : "text-amber-600"
        }`}
      >

        {good
          ? <CheckCircle2 size={14} />
          : <AlertTriangle size={14} />}

        {value}

      </span>

    </div>
  );
}

export default DashboardPage;