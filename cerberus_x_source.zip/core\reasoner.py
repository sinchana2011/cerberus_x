from __future__ import annotations

import calendar
import re
from datetime import datetime
from typing import Optional

from core.entity_resolver import normalize_name
from core.schemas import (
    AnalysisResult,
    Answer,
    AnswerStatus,
    Citation,
    Claim,
    ClaimStatus,
    ConflictType,
    WorkflowStage,
)

_MONTHS = {
    name.lower(): idx
    for idx, name in enumerate(calendar.month_name)
    if name
}
_ROLES = ("ceo", "cfo", "cto", "manager")
_STAGES = {
    "ordered": WorkflowStage.ORDERED,
    "dispatched": WorkflowStage.DISPATCHED,
    "delivered": WorkflowStage.DELIVERED,
    "invoiced": WorkflowStage.INVOICED,
}


def _make_citation(claim: Claim, result: AnalysisResult) -> Optional[Citation]:
    document = result.doc_by_id(claim.source_id)
    if document is None:
        return None
    return Citation(
        source_id=document.id,
        filename=document.filename,
        snippet=claim.raw_text[:300],
        locator=claim.locator,
        reliability=document.reliability,
    )


def _extract_time_window(
    question: str,
) -> tuple[Optional[datetime], Optional[datetime], str]:
    """Return ``(start, end, granularity)`` for temporal expressions in a question."""
    date_match = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", question)
    if date_match:
        y, m, d = map(int, date_match.groups())
        return datetime(y, m, d, 0, 0, 0), datetime(y, m, d, 23, 59, 59), "day"

    month_pattern = "|".join(_MONTHS.keys())
    month_match = re.search(rf"\b({month_pattern})\s+(\d{{4}})\b", question, re.I)
    if month_match:
        month = _MONTHS[month_match.group(1).lower()]
        year = int(month_match.group(2))
        last_day = calendar.monthrange(year, month)[1]
        return datetime(year, month, 1, 0, 0, 0), datetime(year, month, last_day, 23, 59, 59), "month"

    year_match = re.search(r"\bin\s+(\d{4})\b", question, re.I)
    if year_match:
        year = int(year_match.group(1))
        return datetime(year, 1, 1, 0, 0, 0), datetime(year, 12, 31, 23, 59, 59), "year"

    return None, None, "none"


def _entity_matches_question(claim: Claim, result: AnalysisResult, q_norm: str) -> bool:
    """True when the claim's entity (or one of its known aliases / IDs) is named in q."""
    names = [claim.entity_name]
    if claim.entity_id:
        entity = next((e for e in result.entities if e.id == claim.entity_id), None)
        if entity:
            names.append(entity.canonical_name)
            names.extend(entity.aliases)

    for name in names:
        norm = normalize_name(name)
        if not norm:
            continue
        if norm in q_norm:
            return True
        id_tokens = [t for t in norm.split() if any(ch.isdigit() for ch in t)]
        if id_tokens and all(tok in q_norm for tok in id_tokens):
            return True
    return False


def _filter_by_intent(claims: list[Claim], question: str) -> list[Claim]:
    """Filter candidate claims by requested role, workflow stage, or action."""
    q_lower = question.casefold()

    asked_roles = [r for r in _ROLES if re.search(rf"\b{r}\b", q_lower)]
    if asked_roles:
        role_preds = {f"role:{r.upper()}" for r in asked_roles}
        return [c for c in claims if c.predicate in role_preds]

    asked_stages = [
        stage for word, stage in _STAGES.items()
        if re.search(rf"\b{word}\b", q_lower)
    ]
    if asked_stages:
        stage_claims = [
            c for c in claims
            if c.predicate == "quantity" and c.stage in asked_stages
        ]
        if stage_claims:
            return stage_claims
        # If the question mentions a stage for a quantity entity, don't fall back
        # to unrelated predicates.
        if any(c.predicate == "quantity" for c in claims):
            return []

    if re.search(r"\b(arrive|arrived|depart|departed|before|after)\b", q_lower):
        move_claims = [c for c in claims if c.predicate in ("arrived", "departed")]
        if move_claims:
            return move_claims

    return claims


def _matches_time_window(
    claim: Claim,
    result: AnalysisResult,
    start: datetime,
    end: datetime,
) -> bool:
    if claim.event_time is not None:
        return start <= claim.event_time <= end
    # Check digital twin interval if the claim itself has no explicit event_time
    # (e.g., an undated 2024 state superseded in 2026).
    for state in result.twin_states:
        if state.claim_id == claim.id:
            v_from = state.valid_from or datetime.min
            v_to = state.valid_to or datetime.max
            return v_from <= end and start <= v_to
    return False


def _format_claim_detail(claim: Claim) -> str:
    when = f" on {claim.event_time.strftime('%Y-%m-%d %H:%M')}" if claim.event_time else ""
    src = claim.source_label or claim.source_id
    if claim.predicate == "quantity" and claim.stage != WorkflowStage.UNKNOWN:
        unit = f" {claim.unit}" if claim.unit else ""
        return f"{claim.stage.value}={claim.value}{unit}{when} (source: {src})"
    return f"{claim.predicate}={claim.value}{when} (source: {src})"


def _collect_citations(claims: list[Claim], result: AnalysisResult) -> list[Citation]:
    citations: list[Citation] = []
    for claim in claims:
        citation = _make_citation(claim, result)
        if citation and citation not in citations:
            citations.append(citation)
    return citations


def answer_question(
    question: str,
    result: AnalysisResult,
) -> Answer:

    q_norm = normalize_name(question)
    q_lower = question.casefold()
    win_start, win_end, granularity = _extract_time_window(question)

    usable = [
        c for c in result.claims
        if not c.suspicious and c.status != ClaimStatus.DUPLICATE
    ]

    entity_matches = [
        c for c in usable
        if _entity_matches_question(c, result, q_norm)
    ]
    matches = _filter_by_intent(entity_matches, question)

    # Check if only suspicious evidence exists for this question.
    if not matches:
        suspicious_matches = _filter_by_intent(
            [c for c in result.claims if c.suspicious and _entity_matches_question(c, result, q_norm)],
            question,
        )
        if suspicious_matches:
            return Answer(
                question=question,
                status=AnswerStatus.SUSPICIOUS_ONLY,
                answer_text=(
                    "The available evidence is suspicious "
                    "and cannot be used as a verified fact."
                ),
                citations=_collect_citations(suspicious_matches, result),
            )
        return Answer(
            question=question,
            status=AnswerStatus.INSUFFICIENT_EVIDENCE,
            answer_text=(
                "There is insufficient reliable evidence "
                "to answer this question."
            ),
            confidence=0.0,
        )

    if win_start is not None and win_end is not None:
        timed = [c for c in matches if _matches_time_window(c, result, win_start, win_end)]
        if timed:
            matches = timed
    else:
        # Current-state question: prefer non-superseded claims if any exist.
        current = [c for c in matches if c.status != ClaimStatus.SUPERSEDED]
        if current:
            matches = current

    matched_ids = {c.id for c in matches}

    related_conflicts = [
        conflict for conflict in result.conflicts
        if matched_ids.intersection(conflict.claim_ids)
        and (
            set(conflict.claim_ids).issubset(matched_ids)
            or conflict.conflict_type in (
                ConflictType.TRUE_CONFLICT,
                ConflictType.SAME_EVENT_CONFLICT,
                ConflictType.IMPOSSIBLE_TIMELINE,
            )
        )
    ]

    # Check whether the question asks if an entity could visit multiple places
    # across a broader window (compatibility check) rather than at the exact same time.
    asks_compatibility = bool(
        re.search(r"\bcan\b.*\bboth\b|\bcould\b.*\bboth\b", q_lower)
        and not re.search(r"\bsame time\b", q_lower)
    )
    compatible_pairs = [
        c for c in related_conflicts
        if c.conflict_type == ConflictType.COMPATIBLE_DIFFERENT_TIME
    ]
    if asks_compatibility and compatible_pairs:
        pair_claim_ids = {cid for c in compatible_pairs for cid in c.claim_ids}
        compat_claims = sorted(
            [c for c in matches if c.id in pair_claim_ids],
            key=lambda c: c.event_time or datetime.min,
        )
        # Prefer distinct dates so the compatible timeline is clear.
        summary_parts = [
            f"{c.value} on {c.event_time.strftime('%Y-%m-%d at %H:%M')}"
            if c.event_time else c.value
            for c in compat_claims
        ]
        notes = [
            "Compatible events occurred at different times within the queried period."
        ]
        real_in_period = [c for c in related_conflicts if c.is_real_problem]
        if real_in_period:
            notes.append(
                "Note: a simultaneous-location conflict was also recorded on "
                + "; ".join(c.explanation for c in real_in_period)
            )
        return Answer(
            question=question,
            status=AnswerStatus.ANSWERED,
            answer_text=(
                f"Yes, {compat_claims[0].entity_name} has compatible records at different times: "
                + "; ".join(summary_parts)
                + "."
            ),
            confidence=round(
                min((latest_confidence(result, c) for c in compat_claims), default=0.5),
                2,
            ),
            citations=_collect_citations(compat_claims, result),
            conflict_ids=[c.id for c in compatible_pairs],
            notes=notes,
        )

    real_conflicts = [
        conflict for conflict in related_conflicts
        if conflict.is_real_problem
    ]

    citations = _collect_citations(matches, result)

    if real_conflicts:
        conflict_claim_ids = {cid for conf in real_conflicts for cid in conf.claim_ids}
        conflict_claims = [c for c in matches if c.id in conflict_claim_ids] or matches
        details = [_format_claim_detail(c) for c in conflict_claims]
        reasons = "; ".join(c.explanation for c in real_conflicts)

        return Answer(
            question=question,
            status=AnswerStatus.CONFLICTING,
            answer_text=(
                f"Conflicting evidence was found ({reasons}). "
                + "Recorded claims: "
                + "; ".join(details)
                + ". The system cannot safely select one value."
            ),
            confidence=0.5,
            citations=_collect_citations(conflict_claims, result),
            conflict_ids=[c.id for c in real_conflicts],
            notes=[
                "Conflicting claims are presented without automatically selecting a winner."
            ],
        )

    # Multi-stage or multi-part answer (e.g., ordered + dispatched on the same PO).
    distinct_stages = {
        (c.predicate, c.stage) for c in matches
        if c.predicate == "quantity" and c.stage != WorkflowStage.UNKNOWN
    }
    if len(distinct_stages) > 1:
        ordered_claims = sorted(
            matches,
            key=lambda c: (c.event_time is not None, c.event_time or datetime.min),
        )
        parts = [
            f"{c.stage.value} {c.value} {c.unit or 'units'}".strip()
            for c in ordered_claims
        ]
        confs = [latest_confidence(result, c) for c in ordered_claims]
        return Answer(
            question=question,
            status=AnswerStatus.ANSWERED,
            answer_text=(
                f"Based on the available evidence for {ordered_claims[0].entity_name}: "
                + ", and ".join(parts)
                + "."
            ),
            confidence=round(max(0.0, min(1.0, sum(confs) / len(confs))), 2),
            citations=citations,
            notes=[
                "Multiple workflow stages reported without contradiction."
            ],
        )

    matches.sort(
        key=lambda c: (
            c.event_time is not None,
            c.event_time or datetime.min,
        ),
        reverse=True,
    )

    latest = matches[0]
    when = f" (as of {latest.event_time.strftime('%Y-%m-%d')})" if latest.event_time else ""
    unit = f" {latest.unit}" if latest.unit else ""

    answer = (
        f"Based on the available evidence, "
        f"{latest.entity_name}: "
        f"{latest.predicate} = {latest.value}{unit}{when}."
    )

    return Answer(
        question=question,
        status=AnswerStatus.ANSWERED,
        answer_text=answer,
        confidence=round(
            max(0.0, min(1.0, latest_confidence(result, latest))),
            2,
        ),
        citations=citations,
        notes=[
            "Answer generated using local rule-based reasoning."
        ],
    )


def latest_confidence(result: AnalysisResult, claim: Claim) -> float:

    document = result.doc_by_id(claim.source_id)

    if document is None:
        return 0.3

    if claim.status == ClaimStatus.VERIFIED:
        return document.reliability

    return document.reliability * 0.7


class EvidenceReasoner:

    def __init__(self, result: AnalysisResult):
        self.result = result

    def ask(self, question: str) -> Answer:
        return answer_question(question, self.result)

    def ask_many(self, questions: list[str]) -> list[Answer]:
        return [
            self.ask(question)
            for question in questions
        ]